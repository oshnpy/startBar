import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

 const route=new Router({
  routes: [
   {
     path:"/",
     redirect:"/home"
   },
   {
     path:"/home",
     component:()=>import("@/views/Home"),
     meta:{
       title:"加班/休假"
     }
   },
   {
     path:"/origin",
     component:()=>import("@/views/Originating"),
     meta:{
       title:"排序"
     }
   },
   {
     path:"/batch",
     component:()=>import("@/views/Batch"),
     meta:{
      title:"筛选"
    }
   },
   {
     path:"/login",
     component:()=>import("@/views/Login"),
     meta:{
      title:"登录"
    }
   }
  ]
})
route.beforeEach((to,from,next)=>{
 document.title=to.meta.title;
 next()
})
export default route;
