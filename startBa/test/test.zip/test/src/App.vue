<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <router-view/>
  </div>
</template>

<script>
import request from "./utils/request"
export default {
 created(){
  //服务器里面设置了中间件所以设置了跨域
  //  Axios.get("http://localhost:3000/api/user/info").then((res)=>{
  //    console.log(res)
  //  }).catch((res)=>{
  //    console.log(res)
  //  })


  //配置服务器  代理
  request.get("/api/user/info")
 }
}
</script>

<style lang="scss">
@import "./utils/_minix.scss";

#app{
  width:100%;
  height: 100%;
  @include box_flex;
  @include direction(column);
}
</style>
