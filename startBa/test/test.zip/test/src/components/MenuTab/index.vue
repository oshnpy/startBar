<template>
    <div class="chooseBox">
               <dl>
                   <dt class="active">
                        <span class="icon iconfont">&#xe62e;</span>
                   </dt>
                   <dd>待处理</dd>
               </dl>
                 <dl>
                   <dt>
                        <span class="icon iconfont">&#xe606;</span>
                   </dt>
                   <dd>已发起</dd>
               </dl>
                 <dl>
                   <dt>
                         <span class="icon iconfont">&#xe602;</span>
                   </dt>
                   <dd>已处理</dd>
               </dl>
           </div>
</template>
<script>
export default {
    props:{

    },
    components:{

    },
    data(){
        return {
         
        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="scss">
@import "../../utils/common.scss";
@import "../../utils/_minix.scss";
.iconfont{
    font-size: pxTorem(25px);
}
  .chooseBox{
        width:100%;
        height: pxTorem(100px);
        background: #fff;
        @include box_flex;
        box-shadow: 0 25px 50px #eee;
        dl{
            width:33.3%;
            height: 100%;
            @include box_flex;
            @include direction(column);
            @include justify;
            @include align;
        }
        .active{
            background: green;
        }
    }
</style>