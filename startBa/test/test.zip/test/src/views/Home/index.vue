<template>
    <div class="wrapper">
        <header class="header">
         <span class="icon iconfont">&#xe61a;</span>
         <h6>加班/休假</h6>
         <div>
            <span class="icon iconfont">&#xe613;</span>
            <span class="icon iconfont">&#xe615;</span>
         </div>
        </header>
        <section class="section">
           <menuTab/>
          <menuChoose />
           <ul class="listBox">
              <menuList />
           </ul>
           <div class="taskFa">
              +发起任务
           </div>
        </section>
    </div>
</template>
<script>
import menuTab from "../../components/MenuTab"
import menuChoose from "../../components/MenuChoose"
import menuList from "../../components/MenuList"
export default {
    props:{

    },
    components:{
        menuTab,
        menuChoose,
        menuList
    },
    data(){
        return {
            tableOptions:{
                index:0
            }
        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="scss">
@import "../../utils/common.scss";
@import "../../utils/_minix.scss";
.iconfont{
    font-size: pxTorem(25px);
}
.wrapper{
    width:100%;
    height: 100%;
    @include box_flex;
    @include direction(column);
}
.header{
    width:100%;
    height: pxTorem(60px);
   @include box_flex;
   @include align;
   @include justify(space-between);
   padding:0 pxTorem(15px);
   @include sizing;
   h6{
       font-size: pxTorem(17px);
       font-weight: 600;
   }
   div{
      width:pxTorem(70px);
      height: 100%;
      
      @include box_flex;
     @include justify(space-between);
     @include align;
   }
}
.section{
    width:100%;
    @include flex;
//    background: #fff;
   overflow-y:auto;
  
    
  
    .taskFa{
        width:pxTorem(100px);
        height: pxTorem(40px);
        background: #0C6142;
        border-radius:pxTorem(30px);
        text-align: center;
        line-height:pxTorem(40px); 
        position: fixed;
        bottom:pxTorem(30px);
        right:pxTorem(30px);
        color: #fff;
    }
}
</style>