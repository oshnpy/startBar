<template>
     <li>
                  <div class="typeBox">
                      <span>QTDJVJDFV</span>
                      <p>
                          <span class="icon iconfont">&#xe639;</span>
                          <b>待审批</b>
                      </p>
                  </div>
                  <div class="typeFather">
                       <div class="typeChild">
                           <p>
                                <span>申请人</span>
                                 <span>CICI Wang</span>
                           </p>
                           <p>
                                 <span>加班日期</span>
                                 <span>2019-02-02</span>
                           </p>
                     
                     
                  </div>
                   <div class="typeChild">
                       <p>
                            <span>加班类型</span>
                            <span>工作日加班</span>
                       </p>
                     <p>
                         <span>加班时数</span>
                      <span>2.5</span>
                     </p>
                      
                  </div>
                  </div>
                 
               </li>
              
</template>
<script>
export default {
    props:{

    },
    components:{

    },
    data(){
        return {

        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="scss">
@import "../../utils/common.scss";
@import "../../utils/_minix.scss";
  .listBox{
        width:100%;
        li:nth-child(1){
            margin: 0;
        }
        li{
            width:100%;
            height: pxTorem(100px);
            background:#fff;
             padding:0 pxTorem(20px);
             margin-top: pxTorem(5px);
             @include sizing;
            .typeBox{
                width:100%;
                height: pxTorem(20px);
                @include box_flex;
                @include justify(space-between);
                @include align;
              
               
            }
            .typeFather{
                width:100%;
                @include box_flex;
                height: pxTorem(80px);
                @include justify(space-around);
                .typeChild{
                width:50%;
                // background: green;
                @include box_flex;
                @include direction(column);
                // background: pink;
                @include justify;
         
               p{
                padding:pxTorem(5px);
                @include sizing;
                span{
                padding-right:pxTorem(5px);
                @include sizing;
                }
               }
             
            }
             .typeChild:nth-child(2){
                   margin-left: pxTorem(100px);
                   @include sizing;
               }
            }
            
        }
    }
</style>